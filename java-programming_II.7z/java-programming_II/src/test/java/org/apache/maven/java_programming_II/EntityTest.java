package org.apache.maven.java_programming_II;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class EntityTest extends TestCase{

}
